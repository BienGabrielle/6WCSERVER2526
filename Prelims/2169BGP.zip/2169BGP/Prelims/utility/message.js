//Message.js
exports.SimpleMessage = "Hello World"
//or module.exports.SimpleMessage = "Hello World";

