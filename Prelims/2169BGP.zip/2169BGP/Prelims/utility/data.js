module.exports = {
    firstname: "Gabo",
    lastname: "Pangilinan"
};