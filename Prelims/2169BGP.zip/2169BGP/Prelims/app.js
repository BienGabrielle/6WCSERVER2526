var myLogModule = require('./utility/log.js');

myLogModule.warning('Warning node not configured..');
myLogModule.error('Node encountered an error..');
myLogModule.info('Node running...');

// var msg = require('./utility/message.js');
// console.log(msg);

// var person = require('./utility/data.js');
// console.log(person.firstname + ' ' +person.lastname);

// var msg = require('./utility/log.js')
// msg('Hello World');