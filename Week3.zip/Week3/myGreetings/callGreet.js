const greet = require('./greet')

console.log(greet('John'));
console.log(greet('Jane'));