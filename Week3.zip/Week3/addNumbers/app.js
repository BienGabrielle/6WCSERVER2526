const add = require('./add');

const result = add(10,20);
console.log("10 + 20 = ", result);

const result1 = add(20,20);
console.log("20 + 20 = ", result1);
